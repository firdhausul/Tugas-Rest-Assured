public class Parent {

    String property1 = "Property 1";
    String property2 = "Property 2";

    public void method1()
    {
        System.out.println("Ini method 1 di parent");
    }

    public void method2()
    {
            System.out.println("Ini method 2 di parent");
    }
}