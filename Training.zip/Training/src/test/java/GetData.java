import Share.BaseTest;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class GetData extends BaseTest {
    @Test
    public void GetResponseData(){
        //RestAssured.baseURI = "https://regres.in";
        RequestSpecification request = given();
        request.param("page", 2);
        Response response = request.get("/api/users");
        response.then().assertThat().statusCode(200);
        System.out.println(response.asString());

        String page = response.jsonPath().getString("page");
        System.out.println("page :"+page);
        String email = response.jsonPath().getString("data[0].email");
        System.out.println("email :"+email);
    }

}
