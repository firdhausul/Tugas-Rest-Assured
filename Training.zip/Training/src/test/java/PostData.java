import Share.BaseTest;
import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.hamcrest.core.Is;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;

import static io.restassured.RestAssured.given;

public class PostData extends BaseTest {
    @Test (dataProvider = "data-users")
    public void sendPostData(String name, String job) throws JSONException {
        RequestSpecification request = given();

        JSONObject params = new JSONObject();
        params.put("name", name);
        params.put("job", job);

        System.out.println(params.toString());

        //request.header("Content-Type", "application/json");

        //Response response = request.post("/api/users");


        //response.then().assertThat()
                //.statusCode(201);
        //.body("name", Is.is("Firdha"))
        //.body("job", Is.is("QA"))
                //.body(JsonSchemaValidator.matchesJsonSchema(
                        //new File("src/resources/Scema/Users/SuccesCreateUserScema.json")
                //));
        //System.out.println(response.asString());

    }
    @DataProvider(name = "data-users")
    Object[][]DataUsers(){
        Object[][] users = new Object[][]{
                {"Jhon", "Backend"},
                {"doe", "frontend"},
                {"yes", "QA"}
    };
        return users;

}}
