package Register;

import Share.BaseTest;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class RegisterSuccess extends BaseTest {
    @Test
    public void register (){
        Map<String, Object> jsonAsMap = new HashMap<>();
        jsonAsMap.put("email", "eve.holt@reqres.in");
        jsonAsMap.put("password", "pistol");

        given().
                contentType("application/json").
                body(jsonAsMap).
                when().
                post("api/register")
                .then().statusCode(200).log().body();
    }
}
