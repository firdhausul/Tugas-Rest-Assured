import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.Test;

public class SecondTest {

    @Test
    public void CreateUserTest() throws JSONException {
        JSONObject params = new JSONObject();

   params.put("name", "Jhon Tere");
//        params.put("Job", "Leader");

        System.out.println(params.toString());
    }
}



