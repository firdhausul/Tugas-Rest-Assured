package Users;

import Share.BaseTest;
import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.hamcrest.core.Is;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;

import static io.restassured.RestAssured.given;

public class CreateData extends BaseTest {
    @Test (dataProvider = "data-users")
    public void sendPostData(String name, String job) throws JSONException {
        RequestSpecification request = given();

        JSONObject params = new JSONObject();
        params.put("name", name);
        params.put("job", job);

        System.out.println(params.toString());

    }
    @DataProvider(name = "data-users")
    Object[][]DataUsers(){
        Object[][] users = new Object[][]{
                {"Firdha", "QA"},
                {"Firdhausul", "QA"},
                {"Usul", "QA"}
        };
        return users;

    }}
